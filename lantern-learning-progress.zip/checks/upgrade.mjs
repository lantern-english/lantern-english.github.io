import fs from 'node:fs/promises';
import vm from 'node:vm';
const root='work/lantern-repo';
let app=await fs.readFile('work/before-upgrade/app.js','utf8');
app=app.replace('  const VIDEO_BY_ID', '  const Learning = window.LanternLearning;\r\n  const VIDEO_BY_ID');
app=app.replace('<div class="video-art" aria-hidden="true">${ICON.play}<span>İzle</span></div>','${Learning.cover(v)}');
app=app.replace('YouTube videolarında altyazıyı oynatıcıdan aç.','YouTube videolarına İngilizce altyazı dosyanı ekleyerek aynı şekilde çalış.');
app=app.replace('${v.provider === "youtube" ? "YouTube oynatıcısı" : "Dokunulabilir İngilizce altyazı"}', '${v.provider === "youtube" ? "YouTube · kendi altyazını ekle" : "Dokunulabilir İngilizce altyazı"}');
const start=app.indexOf('  function viewYouTubeVideo(v) {'), end=app.indexOf('  function viewVideo(id) {',start);
app=app.slice(0,start)+app.slice(end);
app=app.replace('    if (v.provider === "youtube") { viewYouTubeVideo(v); return; }',`    if (v.provider === "youtube") { Learning.youtube(v); Learning.lesson(v, true); return; }
    if (!v.captions) {
      $main.innerHTML = '<div class="empty"><p role="status">Altyazı hazırlanıyor…</p></div>';
      const expectedRoute = location.hash;
      Learning.captions().then((captions) => {
        if (location.hash !== expectedRoute) return;
        if (!Array.isArray(captions[id]) || !captions[id].length) throw Error('Bu videonun altyazısı bulunamadı.');
        v.captions = captions[id]; viewVideo(id);
      }).catch((error) => {
        if (location.hash !== expectedRoute) return;
        $main.innerHTML = '<div class="empty"><p role="alert">'+esc(error.message)+'</p><button class="btn" id="caption-retry">Yeniden dene</button></div>';
        document.getElementById('caption-retry').onclick = () => viewVideo(id);
      });
      return;
    }`);
// Add lesson and continuation tracking once native player construction is complete.
const nextView=app.indexOf('  function viewMyLibrary()');
const nativeEnd=app.lastIndexOf('  }',nextView);
app=app.slice(0,nativeEnd)+'    Learning.nativeProgress(v);\r\n    Learning.lesson(v, true);\r\n'+app.slice(nativeEnd);
app=app.replace('    if (videoCleanup) { videoCleanup(); videoCleanup = null; }','    Learning.cleanup();\r\n    if (videoCleanup) { videoCleanup(); videoCleanup = null; }');
app=app.replace('    else if (h === "about") viewAbout();','    else if (h === "about") viewAbout();\r\n    else if (h === "study") Learning.study();\r\n    else if (h === "backup") Learning.backup();');
app=app.replace('    else viewHome();','    else viewHome();\r\n    Learning.afterRoute(h);');
app=app.replace('  window.addEventListener("hashchange", route);',`  Learning.init({main:$main, videos:VIDEOS, library:LIB, renderInline, bindText, markSaved, toast,
    category:videoCategory, playIcon:ICON.play, hideTip:()=>Tip.hide(),
    reloadPersonal:()=>{words=S.load('words',{});progress=S.load('progress',{});bookmarks=cleanBookmarks(S.load('bookmarks',[]));updateBookmarks();}
  });
  window.addEventListener("hashchange", route);`);
app=app.replaceAll('src: BY_ID[text.id] ? text.id : null','src: (BY_ID[text.id] || VIDEO_BY_ID[text.id]) ? text.id : null');
app=app.replace('const src = w.src && BY_ID[w.src];','const src = w.src && (BY_ID[w.src] || VIDEO_BY_ID[w.src]);');
app=app.replace('href="#s.${src.id}"','href="#${VIDEO_BY_ID[src.id] ? "v" : "s"}.${src.id}"');
await fs.writeFile(root+'/assets/js/app.js',app.replace(/\r?\n/g,'\r\n'));
const context={window:{}};vm.createContext(context);vm.runInContext(await fs.readFile('work/before-upgrade/videos.js','utf8'),context);
const captions={};const catalog=context.window.LANTERN_VIDEOS.map(v=>{if(v.captions?.length)captions[v.id]=v.captions;return {...v,captions:undefined};});
await fs.writeFile(root+'/data/videos.js','/* Video catalog: full captions load when a video is opened. */\nwindow.LANTERN_VIDEOS = '+JSON.stringify(catalog)+';\n');
await fs.writeFile(root+'/data/video-captions.js','/* Source credits and licenses are recorded per video in videos.js. */\nwindow.LANTERN_CAPTIONS = '+JSON.stringify(captions)+';\n');
let html=await fs.readFile('work/before-upgrade/index.html','utf8');
html=html.replace('<a href="#library" data-nav="library">','<a href="#study" data-nav="study">Çalışma Planım</a>\n      <a href="#library" data-nav="library">');
html=html.replace('<script src="assets/js/app.js"></script>','<script src="assets/js/learning.js"></script>\n<script src="assets/js/app.js"></script>');
html=html.replaceAll('<script src=','<script defer src=');
await fs.writeFile(root+'/index.html',html);
let sw=await fs.readFile('work/before-upgrade/sw.js','utf8');
sw=sw.replace('"assets/js/app.js",','"assets/js/app.js", "assets/js/learning.js",');
sw=sw.replace(/const VERSION = "[^"]+";/,'const VERSION = "learning-20261013-1";');
await fs.writeFile(root+'/sw.js',sw);
console.log('Integrated learning tools, split caption payload, and refreshed offline shell.');
