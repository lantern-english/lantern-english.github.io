const Learning=window.LanternLearning;
const navigate=async id=>{location.hash='#'+id;for(const fn of listeners.hashchange||[])fn({type:'hashchange'});await new Promise(r=>setTimeout(r,5));};
const click=el=>el.dispatchEvent(new domWindow.Event('click',{bubbles:true}));
const change=el=>el.dispatchEvent(new domWindow.Event('change',{bubbles:true}));
assert.equal(document.querySelectorAll('.video-card').length,31);
for(const v of window.LANTERN_VIDEOS){
 await navigate('v.'+v.id);assert.equal(document.querySelector('h1').textContent,v.title);
 assert.ok(document.querySelector('.lesson'),v.id+' lesson');
 if(v.provider==='youtube'){
  assert.equal(document.querySelector('iframe'),null);assert.ok(document.getElementById('yt-sub-file'));
  const word=document.querySelector('#youtube-vocabulary .w');click(word);assert.ok(!document.getElementById('tip').hidden);
  assert.ok(document.getElementById('tip').textContent.includes(Object.values(v.glossary)[0]));
 }else{assert.ok(document.getElementById('video-player'));assert.equal(document.querySelectorAll('#caption-select option').length,v.captions.length);}
}
console.log('All video routes render with learning exercises and correct player.');
await navigate('videos');
document.getElementById('video-level').value='C2';change(document.getElementById('video-level'));
let visible=[...document.querySelectorAll('.video-card')].filter(x=>!x.hidden);assert.equal(visible.length,2);assert.ok(visible.every(x=>x.textContent.includes('C2')));
document.getElementById('video-search').value='zzzz';change(document.getElementById('video-search'));assert.ok([...document.querySelectorAll('.video-card')].every(x=>x.hidden));
click(document.getElementById('video-reset'));assert.equal([...document.querySelectorAll('.video-card')].filter(x=>!x.hidden).length,31);
click(document.querySelector('[data-video-cat="horror"]'));assert.equal(document.querySelector('[data-shelf="horror"]').hidden,false);assert.equal(document.querySelector('[data-shelf="real"]').hidden,true);
console.log('Search, CEFR, empty results, reset, and genre filtering pass.');
const sample='WEBVTT\n\n00:00:01.000 --> 00:00:04.000\nThe expert speaks.\n\n00:00:05.000 --> 00:00:08.000\nWe need evidence.';
assert.equal(Learning.parseSubtitles(sample).length,2);
assert.equal(Learning.parseSubtitles('1\n00:00:00,000 --> 00:00:02,000\n<b>expert</b> &amp; evidence')[0].text,'expert & evidence');
assert.throws(()=>Learning.parseSubtitles('no timestamp'));
assert.throws(()=>Learning.parseSubtitles('00:00:05.000 --> 00:00:02.000\nbad'));
localStorage.setItem('lantern.subtitles.the-expert',JSON.stringify({cues:Learning.parseSubtitles(sample),offset:0}));
let fakePlayer;
window.YT={Player:class {
 constructor(id,opts){this.time=0;this.state=2;this.opts=opts;fakePlayer=this;const iframe=document.createElement('iframe');iframe.src='https://www.youtube-nocookie.com/embed/'+opts.videoId;document.getElementById(id).replaceWith(iframe);setTimeout(()=>opts.events.onReady(),0);}
 getCurrentTime(){return this.time;}getPlayerState(){return this.state;}seekTo(t){this.time=t;}pauseVideo(){this.state=2;}playVideo(){this.state=1;this.opts.events.onStateChange({data:1});}destroy(){this.destroyed=true;}
}};
await navigate('v.the-expert');click(document.getElementById('youtube-start'));await new Promise(r=>setTimeout(r,10));
assert.ok(document.querySelector('iframe'));fakePlayer.time=2;await new Promise(r=>setTimeout(r,180));
assert.ok(document.getElementById('yt-caption').textContent.includes('expert'));
click(document.querySelector('#yt-caption .w'));assert.equal(fakePlayer.state,2);assert.equal(document.getElementById('tip').hidden,false);
click(document.getElementById('yt-next'));assert.equal(fakePlayer.time,5);assert.ok(document.getElementById('yt-caption').textContent.includes('evidence'));
click(document.getElementById('yt-repeat'));assert.equal(fakePlayer.state,1);fakePlayer.time=8.2;await new Promise(r=>setTimeout(r,180));assert.equal(fakePlayer.state,2);
click(document.getElementById('yt-resume'));assert.equal(fakePlayer.state,1);
await navigate('videos');assert.ok(fakePlayer.destroyed);
console.log('YouTube API integration: subtitle sync, word pause, cue navigation, repeat endpoint, resume and cleanup pass.');
await navigate('v.the-expert');click(document.querySelector('[data-answer="0"]'));assert.match(document.querySelector('#comprehension .answer-feedback').textContent,/Doğru/);
const reflection=document.getElementById('reflection');reflection.value='Evidence supports my opinion.';reflection.dispatchEvent(new domWindow.Event('input',{bubbles:true}));click(document.getElementById('lesson-done'));
await navigate('v.the-expert');assert.equal(document.getElementById('reflection').value,'Evidence supports my opinion.');assert.match(document.getElementById('lesson-done').textContent,/Çalışıldı/);
await navigate('s.'+window.LANTERN_LIBRARY[0].id);assert.ok(document.querySelector('.lesson'));
await navigate('study');assert.ok(document.querySelector('#study-plan .card'));assert.ok(document.querySelector('.study-steps'));
console.log('Content exercises, saved reflections, reading lessons, and personal study plan pass.');
const oldWords=JSON.parse(localStorage.getItem('lantern.words'));
const valid={app:'Lantern English',version:1,data:{words:{evidence:{w:'evidence',tr:'kanıt',added:10,due:0,box:1}},bookmarks:[window.LANTERN_LIBRARY[0].id],learning:{'the-expert':{done:true,note:'Older note',at:0}}}};
const data=Learning.validateBackup(valid);Learning.mergeBackup(data);
assert.ok(JSON.parse(localStorage.getItem('lantern.words')).evidence);assert.ok(JSON.parse(localStorage.getItem('lantern.words')).expert);
assert.equal(JSON.parse(localStorage.getItem('lantern.learning'))['the-expert'].note,'Evidence supports my opinion.');
assert.throws(()=>Learning.validateBackup({app:'wrong',version:1,data:{}}));
assert.throws(()=>Learning.validateBackup(JSON.parse('{"app":"Lantern English","version":1,"data":{"words":{"__proto__":{}}}}')));
assert.throws(()=>Learning.validateBackup({app:'Lantern English',version:1,data:{words:{bad:{w:'bad',tr:'kötü',added:0,due:0,box:99}}}}));
const originalSet=localStorage.setItem;let writes=0;localStorage.setItem=(k,v)=>{if(++writes===2)throw Error('Quota exceeded');originalSet(k,v);};
const before=localStorage.getItem('lantern.words');assert.throws(()=>Learning.mergeBackup(data));assert.equal(localStorage.getItem('lantern.words'),before);localStorage.setItem=originalSet;
console.log('Backup schema, prototype protection, merge preserving newer work, and quota rollback pass.');
for(const route of ['home','library','articles','my-library','words','videos','about','study','backup']){
 await navigate(route);const text=document.getElementById('main').textContent;
 assert.doesNotMatch(text,/\b\d+ (?:hikâye|makale|video|sözlük maddesi|kelime biriktirdin|kart kaldı)/,route+' exposes a total');
 assert.equal(document.querySelector('.stats, .chip-n, #count, #due-badge, #library-badge, [data-bookmark-count]'),null);
}
console.log('All page routes render without prohibited counters.');
