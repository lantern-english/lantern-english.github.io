/* Learning tools. Personal work stays on the learner's device. */
(function () {
  'use strict';
  const levels = ['A1','A2','B1','B2','C1','C2'];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const read = (k,d) => { try { return JSON.parse(localStorage.getItem('lantern.'+k)) ?? d; } catch { return d; } };
  const write = (k,v) => { try { localStorage.setItem('lantern.'+k,JSON.stringify(v)); return true; } catch { return false; } };
  const clock = n => Math.floor(n/60)+':'+String(Math.floor(n%60)).padStart(2,'0');
  let api, dispose = () => {}, captionsPromise, ytPromise;
  const captions = async () => {
    if (window.LANTERN_CAPTIONS) return window.LANTERN_CAPTIONS;
    if (!captionsPromise) captionsPromise = new Promise((resolve,reject) => {
      const s = document.createElement('script'); s.src='data/video-captions.js';
      s.onload=()=>window.LANTERN_CAPTIONS ? resolve(window.LANTERN_CAPTIONS) : reject(Error('Altyazı verisi yüklenemedi.'));
      s.onerror=()=>{s.remove(); captionsPromise=null; reject(Error('Altyazı yüklenemedi. Bağlantını kontrol edip tekrar dene.'));};
      document.head.append(s);
    });
    return captionsPromise;
  };
  function parseSubtitles(source) {
    if (typeof source !== 'string' || source.length>1500000) throw Error('Altyazı dosyası çok büyük.');
    const time = s => s.replace(',','.').split(':').reduce((a,b)=>a*60+Number(b),0);
    const cues=[];
    for (const block of source.replace(/^\uFEFF/,'').replace(/\r/g,'').split(/\n\s*\n/)) {
      if (/^(WEBVTT|NOTE|STYLE|REGION)(?:\s|$)/.test(block.trim())) continue;
      const lines=block.trim().split('\n'), i=lines.findIndex(l=>l.includes('-->'));
      if (i<0) continue;
      const m=lines[i].match(/^\s*((?:\d{2,}:)?\d{2}:\d{2}[.,]\d{3})\s+-->\s+((?:\d{2,}:)?\d{2}:\d{2}[.,]\d{3})(?:\s.*)?$/);
      if (!m) throw Error('Altyazıda geçersiz zaman kodu var. SRT veya WebVTT kullan.');
      const start=time(m[1]), end=time(m[2]);
      const text=lines.slice(i+1).join(' ').replace(/<[^>]*>/g,'').replace(/&(?:amp|lt|gt|quot|apos|nbsp);/g,x=>({'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&apos;':"'",'&nbsp;':' '}[x])).trim();
      if (!(Number.isFinite(start)&&Number.isFinite(end)&&start>=0&&end>start&&end<86400) || text.length>1500) throw Error('Altyazının süresi veya satır uzunluğu geçersiz.');
      if (text) cues.push({start,end,text});
    }
    if (!cues.length || cues.length>12000) throw Error('Okunabilir İngilizce SRT/VTT altyazısı bulunamadı.');
    return cues.sort((a,b)=>a.start-b.start);
  }
  function youtubeAPI() {
    if(window.YT?.Player) return Promise.resolve(window.YT);
    if(!ytPromise) ytPromise=new Promise((resolve,reject)=>{
      const s=document.createElement('script'); let settled=false;
      const timer=setTimeout(()=>{if(!settled){settled=true;ytPromise=null;reject(Error('YouTube bağlantısı kurulamadı. Sayfayı yenileyip tekrar dene.'));}},20000);
      const previous=window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady=()=>{previous?.();if(!settled){settled=true;clearTimeout(timer);resolve(window.YT);}};
      s.src='https://www.youtube.com/iframe_api';
      s.onerror=()=>{clearTimeout(timer);settled=true;ytPromise=null;s.remove();reject(Error('YouTube yüklenemedi.'));};
      document.head.append(s);
    });
    return ytPromise;
  }
  function bindWords(root,item) {
    root.querySelectorAll('.w').forEach(w=>{w.tabIndex=0;w.setAttribute('role','button');w.setAttribute('aria-label',w.textContent+' · Türkçe anlamını gör');});
    api.bindText(root,item); api.markSaved(root);
    root.addEventListener('keydown',e=>{if(['Enter',' '].includes(e.key)&&e.target.matches('.w')){e.preventDefault();e.target.click();}});
  }
  const videoRecord=id=>read('videoProgress',{})[id]||{};
  function saveVideo(id,time,done=false) {
    if(!Number.isFinite(time)||time<0) return;
    const records=read('videoProgress',{}), old=records[id]||{};
    records[id]={time,done:done||!!old.done,at:Date.now()};
    write('videoProgress',records);
  }
  function youtube(v) {
    const main=api.main, saved=read('subtitles.'+v.id,null);
    let cues=Array.isArray(saved?.cues)?saved.cues:(v.captions||[]), offset=Number(saved?.offset)||0;
    let player=null, ready=false, dead=false, timer=null, selected=-1, lastSaved=0, repeatEnd=null, frozen=false;
    main.innerHTML=`<article class="video-view" data-id="${esc(v.id)}">
      <nav class="crumbs"><a href="#videos">Videolar</a><span>›</span><span>${esc(v.title)}</span></nav>
      <header class="reader-head"><div class="card-top"><span class="lvl lvl-${v.level}">${v.level}</span><span>${clock(v.durationSeconds)} · ${esc(api.category(v).label)}</span></div><h1>${esc(v.title)}</h1><p class="by">${esc(v.creator)} · ${v.year}</p><p class="lead">${esc(v.summaryTr)}</p><p class="video-level-note">${esc(v.levelNoteTr)}</p>${v.advisoryTr?`<p class="video-advisory">${esc(v.advisoryTr)}</p>`:''}</header>
      <div class="youtube-study-stage"><div class="video-frame" id="youtube-frame"><div class="video-placeholder"><span aria-hidden="true">${api.playIcon}</span><p>${videoRecord(v.id).time>5?'Kaldığın yerden devam edebilirsin.':'İzle, duraklat, bir cümleyi yeniden dinle.'}</p><button class="btn primary" id="youtube-start">Videoyu başlat</button></div></div>
      <section class="panel youtube-transcript" aria-labelledby="yt-caption-heading"><div class="section-head"><h2 id="yt-caption-heading">Dokunarak öğren</h2><span id="yt-time"></span></div>
        <p id="yt-status" role="status"></p><div id="yt-caption" class="reader-text" lang="en"></div>
        <div class="caption-controls" id="yt-controls" hidden><button class="btn sm" id="yt-prev" aria-label="Önceki altyazı">← Önceki</button><button class="btn sm" id="yt-repeat">Cümleyi tekrar dinle</button><button class="btn sm" id="yt-next" aria-label="Sonraki altyazı">Sonraki →</button><button class="btn sm" id="yt-resume">Devam et</button></div>
      </section></div>
      <details class="panel subtitle-tools" ${cues.length?'':'open'}><summary>İngilizce altyazı ekle / zamanlamayı ayarla</summary><p>YouTube’un CC altyazısı buraya otomatik aktarılamıyor. Bu filme ait İngilizce SRT veya VTT dosyanı seç; videoyla eşzamanlı kelimelere dokun, anlamını gör ve defterine kaydet. Dosya yalnızca bu tarayıcıda saklanır.</p>
        <label class="field">Altyazı dosyası<input id="yt-sub-file" type="file" accept=".srt,.vtt,text/vtt,text/plain"></label>
        <label class="field">Altyazı gecikmesi (saniye)<input id="yt-offset" type="number" step="0.1" min="-120" max="120" value="${offset}"></label><p class="sub">Altyazı erken geliyorsa pozitif, geç geliyorsa negatif değer kullan.</p><button class="btn sm" id="yt-clear">Eklediğim altyazıyı kaldır</button><p id="yt-file-status" role="status"></p>
      </details>
      <section class="panel"><h2>İzlemeden önce kelimeler</h2><p class="sub">Kelimeye dokunarak anlamını gör; izlerken kullanımına dikkat et.</p><div class="reader-text vocab-cloud" id="youtube-vocabulary" lang="en">${Object.keys(v.glossary||{}).map(w=>`<p>${api.renderInline(w,[])}</p>`).join('')}</div></section>
      <p class="video-credit"><a href="${esc(v.source.watchUrl||v.source.url)}" target="_blank" rel="noopener">Yayıncının sayfasında aç ↗</a> · ${esc(v.source.credit)}. Öğrenme görevleri Lantern English tarafından hazırlanmıştır.</p>
    </article>`;
    const el=id=>document.getElementById(id), caption=el('yt-caption'), status=el('yt-status');
    const draw=i=>{
      if(selected===i) return; selected=i;
      caption.innerHTML=i>=0?`<p>${api.renderInline(cues[i].text,[])}</p>`:'';
      caption.querySelectorAll('.w').forEach(w=>{w.tabIndex=0;w.setAttribute('role','button');});
      api.markSaved(caption); el('yt-time').textContent=i>=0?clock(cues[i].start+offset):'';
      el('yt-prev').disabled=i<=0;el('yt-next').disabled=i<0||i>=cues.length-1;el('yt-repeat').disabled=i<0;
    };
    const state=()=>{el('yt-controls').hidden=!cues.length;status.textContent=cues.length?'Bir kelimeye dokunduğunda video durur. “Devam et” ile izlemeyi sürdür.':'Dokunulabilir altyazı henüz eklenmedi. Aşağıdan İngilizce altyazı dosyası ekleyebilirsin.'; if(cues.length)draw(0);else{selected=-2;draw(-1);}};
    const seek=i=>{if(!cues[i])return;frozen=true;draw(i);if(ready){player.seekTo(Math.max(0,cues[i].start+offset),true);player.pauseVideo();}else status.textContent='Bu cümleyi dinlemek için önce videoyu başlat.';};
    caption.addEventListener('pointerdown',e=>{if(e.target.closest('.w')&&ready){player.pauseVideo();frozen=true;}},true);
    caption.addEventListener('click',e=>{if(e.target.closest('.w')&&ready){player.pauseVideo();frozen=true;}},true);
    bindWords(caption,v);bindWords(el('youtube-vocabulary'),v);
    el('yt-prev').onclick=()=>seek(Math.max(0,selected-1));el('yt-next').onclick=()=>seek(Math.min(cues.length-1,selected+1));
    el('yt-repeat').onclick=()=>{if(!ready){status.textContent='Önce videoyu başlat.';return;}if(cues[selected]){api.hideTip();frozen=false;repeatEnd=cues[selected].end+offset;player.seekTo(Math.max(0,cues[selected].start+offset),true);player.playVideo();}};
    el('yt-resume').onclick=()=>{if(ready){frozen=false;repeatEnd=null;api.hideTip();player.playVideo();}else status.textContent='Önce videoyu başlat.';};
    el('yt-sub-file').onchange=async e=>{
      const file=e.target.files[0]; if(!file)return;
      try {if(file.size>1500000)throw Error('Dosya çok büyük.');const parsed=parseSubtitles(await file.text());if(dead)return;
        cues=parsed;selected=-2;frozen=false;state();
        el('yt-file-status').textContent=write('subtitles.'+v.id,{cues,offset})?'Altyazı eklendi ve bu tarayıcıya kaydedildi.':'Altyazı bu oturumda kullanılabilir; tarayıcı depolaması dolu olduğu için kaydedilemedi.';
      } catch(error){if(!dead)el('yt-file-status').textContent=error.message;}
    };
    el('yt-offset').onchange=e=>{const n=Number(e.target.value);if(!Number.isFinite(n)||Math.abs(n)>120){e.target.value=offset;return;}offset=n;if(cues.length&&!write('subtitles.'+v.id,{cues,offset}))el('yt-file-status').textContent='Zamanlama değişti; kalıcı kayıt için depolama alanı yok.';};
    el('yt-clear').onclick=()=>{try{localStorage.removeItem('lantern.subtitles.'+v.id);}catch{}cues=v.captions||[];offset=0;el('yt-offset').value=0;selected=-2;state();el('yt-file-status').textContent='Bu filme eklediğin altyazı kaldırıldı.';};
    el('youtube-start').onclick=async e=>{
      const button=e.currentTarget;button.disabled=true;button.textContent='Oynatıcı hazırlanıyor…';
      try{const YT=await youtubeAPI();if(dead)return;const mount=document.createElement('div');mount.id='yt-player';el('youtube-frame').replaceChildren(mount);
        player=new YT.Player('yt-player',{host:'https://www.youtube-nocookie.com',videoId:v.youtubeId,width:'100%',height:'100%',playerVars:{playsinline:1,cc_load_policy:1,cc_lang_pref:'en',rel:0,origin:location.origin},events:{
          onReady:()=>{if(dead)return;ready=true;const resume=videoRecord(v.id);if(resume.time>5&&!resume.done)player.seekTo(resume.time,true);player.playVideo();
            timer=setInterval(()=>{if(dead||!ready)return;const t=player.getCurrentTime();if(repeatEnd!==null&&t>=repeatEnd){player.pauseVideo();repeatEnd=null;frozen=true;}
              if(!frozen&&cues.length){const ct=t-offset;let lo=0,hi=cues.length;while(lo<hi){const mid=(lo+hi)>>1;if(cues[mid].start<=ct)lo=mid+1;else hi=mid;}const i=lo-1;draw(i>=0&&ct<cues[i].end?i:-1);}
              if(player.getPlayerState()===1&&Date.now()-lastSaved>5000){lastSaved=Date.now();saveVideo(v.id,t);}
            },150);
          },onStateChange:e=>{if(e.data===1)frozen=false;if(e.data===0)saveVideo(v.id,player.getCurrentTime(),true);},
          onError:()=>{status.textContent='Yayıncı bu videonun burada oynatılmasına izin vermiyor veya video kullanılamıyor. Yayıncının sayfasındaki bağlantıyı deneyebilirsin.';}
        }});
      }catch(error){if(!dead){button.disabled=false;button.textContent='Yeniden dene';status.textContent=error.message;}}
    };
    state();
    dispose=()=>{dead=true;clearInterval(timer);if(ready)saveVideo(v.id,player.getCurrentTime(),player.getPlayerState()===0);player?.destroy?.();};
  }
  const prompts={
    fun:['What makes this situation funny?','Bir beklentiyi ve onun nasıl bozulduğunu anlat. Mizahı açıklarken actually, although ve instead kullanmayı dene.'],
    horror:['How does the film create suspense?','Bir ses, bir görüntü ve karakterin kararını örnek ver. Kanıt olarak bir sahneyi anlat; sadece scary demekle yetinme.'],
    scifi:['What changes when technology gains power?','Filmdeki bir kuralı belirle. Bu kural değişseydi ne olurdu? If …, would … yapısıyla kendi senaryonu kur.'],
    adventure:['Which decision changes the journey?','Bir kararın nedenini ve sonucunu anlat. First, however ve as a result ile olaylar arasında bağlantı kur.'],
    real:['What claim does the speaker support?','Ana iddiayı, verilen bir kanıtı ve aklında kalan bir soruyu ayrı cümlelerle yaz.']
  };
  const questions={
    'the-expert':['What is the main source of the conflict?',['The requests contradict each other.','The expert arrives at the wrong meeting.','Nobody understands the language.'],0,'Gereksinimler birbiriyle çelişir; uzman teknik gerçekliği anlatmaya çalışırken sosyal baskıyla karşılaşır.'],
    'alternative-math':['What does the film satirize?',['A school without mathematics.','Pressure to accept a claim despite evidence.','The invention of a new number system.'],1,'Öykü, açık bir matematiksel gerçeğin inkâr edilmesi üzerinden otorite ve toplumsal baskıyı hicveder.'],
    'the-gunfighter':['How does the narrator affect the characters?',['They cannot hear the narration.','He translates their words.','His revelations change their behaviour.'],2,'Karakterler anlatıcıyı duyar; açıkladığı sırlar sahnedeki ilişkileri ve davranışları değiştirir.'],
    'rha':['Which situation drives the conversation?',['A prisoner is being interrogated.','Friends are planning a holiday.','A pilot is teaching a class.'],0,'Sorgulama sahnesindeki güç ilişkisine dikkat et: soruyu kimin sorduğu ve yanıtı kimin kontrol ettiği önemlidir.'],
    'rakka':['What is the central struggle?',['Building a peaceful tourist colony.','Human survival under alien occupation.','Choosing a new school leader.'],1,'İşgal ve hayatta kalma çatışması, direnişin nedenlerini ve karakterlerin risklerini şekillendirir.'],
    'night-of-the-living-dead':['Why is cooperation difficult in the house?',['Everyone agrees on one plan.','Nobody faces any danger.','The survivors disagree about how to stay safe.'],2,'Dışarıdaki tehdit kadar içerideki anlaşmazlıklar da önemlidir. Farklı güvenlik planlarını karşılaştır.'],
    'little-shop-of-horrors':['What makes the plant dangerous?',['Its appetite becomes a threat.','It cannot grow indoors.','It needs too much sunlight.'],0,'Kara mizah, alışılmış bir dükkân ortamıyla bitkinin korkunç ihtiyaçları arasındaki çelişkiye dayanır.'],
    'his-girl-friday':['What repeatedly pulls Hildy back toward reporting?',['An assignment to teach children.','A major news story and her professional instincts.','A request to run a restaurant.'],1,'Hildy’nin özel hayatıyla mesleki kimliği çatışır. Hızlı diyaloglardaki ikna ve yönlendirme girişimlerini ayırt et.'],
    'nasa-water-cycle':['Why observe the water cycle from space?',['To stop rain everywhere.','To replace every ground measurement.','To study water movement across the planet.'],2,'Uydu gözlemleri küresel örüntüleri anlamaya yardım eder; yerde yapılan ölçümleri gereksiz kılmaz.'],
    'nasa-carbon-cycle':['Why is carbon described as part of a cycle?',['It moves between connected parts of the Earth system.','It stays permanently in one place.','Only machines contain carbon.'],0,'Atmosfer, canlılar, okyanuslar ve kara arasındaki değişimleri düşün. Bir süreç adıyla yönünü açıklamayı dene.']
  };
  function lesson(item,isVideo) {
    const parent=api.main.querySelector(isVideo?'.video-view':'.reader');if(!parent)return;
    const records=read('learning',{}), old=records[item.id]||{};
    const glossary=Object.entries(item.glossary||{}).filter(([w,m])=>typeof m==='string'&&w.length>2);
    const prompt=prompts[item.category]||['What changes between the beginning and the end?','Ana fikri kendi İngilizce cümlelerinle anlat. Bir ayrıntıyı kanıt olarak kullan ve kişisel yorumunu metindeki bilgiden ayır.'];
    const box=document.createElement('section');box.className='panel lesson';box.id='practice';
    box.innerHTML=`<p class="eyebrow">Anlamadan anlatmaya</p><h2>${isVideo?'İzlediklerini':'Okuduklarını'} kullan</h2><p class="sub">Önce ana fikri yakala, sonra kelimeleri bağlamda hatırla. Yanıtların bu tarayıcıda saklanır.</p>
      <div class="lesson-grid"><div><h3>Kendini yokla</h3><div id="comprehension"></div><div id="vocab-practice"></div></div>
      <div><h3>Kendi cümlelerinle</h3><p lang="en">${esc(prompt[0])}</p><p class="sub">${esc(prompt[1])}</p><label class="field" for="reflection">İngilizce yanıtın<textarea id="reflection" maxlength="4000" rows="5" placeholder="I think… because…">${esc(old.note||'')}</textarea></label><p id="note-status" role="status"></p><details><summary>Yanıtını gözden geçir</summary><ul><li>Ana fikri açıkça söyledim.</li><li>İçerikten somut bir örnek verdim.</li><li>Yeni bir kelimeyi kendi cümlemde kullandım.</li><li>Yanıtımı sesli okuyup anlaşılır olup olmadığını dinledim.</li></ul><p class="sub">Bu bir öz değerlendirme görevidir; otomatik yazı puanlaması yapılmaz.</p></details></div></div>
      <div class="lesson-actions"><button class="btn primary" id="lesson-done">${old.done?'Çalışıldı ✓':'Çalışmayı tamamladım'}</button><a class="btn" href="#words">Kelime kartlarıyla pekiştir</a><a class="btn" href="#study">Sıradaki çalışmam</a></div>`;
    parent.append(box);
    const persist=patch=>{const latest=read('learning',{});latest[item.id]={...(latest[item.id]||{}),...patch,at:Date.now()};return write('learning',latest);};
    box.querySelector('#reflection').oninput=e=>{box.querySelector('#note-status').textContent=persist({note:e.target.value})?'Yanıtın kaydedildi.':'Yanıt kaydedilemedi. Tarayıcında depolama alanı aç veya yanıtını kopyala.';};
    box.querySelector('#lesson-done').onclick=e=>{if(persist({done:true})){e.target.textContent='Çalışıldı ✓';api.toast('Çalışman kaydedildi. Sıradaki öneri çalışma planında.');}else api.toast('Çalışma durumu kaydedilemedi.');};
    const q=questions[item.id], comprehension=box.querySelector('#comprehension');
    if(q){comprehension.innerHTML=`<fieldset><legend lang="en">${esc(q[0])}</legend>${q[1].map((a,i)=>`<button class="answer" data-answer="${i}" lang="en">${esc(a)}</button>`).join('')}<p role="status" class="answer-feedback"></p></fieldset>`;comprehension.onclick=e=>{const b=e.target.closest('[data-answer]');if(!b)return;const ok=+b.dataset.answer===q[2];comprehension.querySelector('.answer-feedback').textContent=(ok?'Doğru. ':'Tekrar düşün. ')+q[3];b.dataset.result=ok?'correct':'retry';};}
    else comprehension.innerHTML=`<p lang="en">${isVideo?'What is the main idea of this video?':'What is the central idea of this text?'}</p><details><summary>Özetle karşılaştır</summary><p>${esc(item.summaryTr)}</p><p class="sub">Yanıtın bu fikri kendi sözcüklerinle aktarıyor mu? Ayrıntıları yeniden kontrol et.</p></details>`;
    let index=0;const quiz=box.querySelector('#vocab-practice');
    const draw=()=>{if(glossary.length<3){quiz.innerHTML='<p>Bilmediğin kelimeleri defterine ekleyip kartlarla tekrar et.</p>';return;}
      const [word,meaning]=glossary[index%glossary.length];let options=[meaning,...glossary.map(x=>x[1]).filter((m,i,a)=>m!==meaning&&a.indexOf(m)===i).slice(0,2)];
      if(options.length<3){quiz.innerHTML='';return;}const rotation=index%3;options=options.slice(rotation).concat(options.slice(0,rotation));
      quiz.innerHTML=`<h3>Kelimeyi hatırla</h3><p><strong lang="en">${esc(word)}</strong> bu içerikte ne anlama geliyor?</p>${options.map((m,i)=>`<button class="answer" data-vocab="${i}">${esc(m)}</button>`).join('')}<p class="answer-feedback" role="status"></p><button class="btn sm" id="vocab-next" hidden>Başka bir kelime</button>`;
      quiz.onclick=e=>{const b=e.target.closest('[data-vocab]');if(b){const ok=options[+b.dataset.vocab]===meaning;b.dataset.result=ok?'correct':'retry';quiz.querySelector('.answer-feedback').textContent=ok?'Doğru. Şimdi bu kelimeyle bir cümle kur.':'Bu anlam uymuyor. İçeriği hatırlayıp yeniden dene.';if(ok)quiz.querySelector('#vocab-next').hidden=false;}if(e.target.closest('#vocab-next')){index++;draw();}};
    };draw();
  }
  function nativeProgress(v) {
    const player=document.getElementById('video-player');if(!player)return;
    const old=videoRecord(v.id);let last=0;
    player.addEventListener('loadedmetadata',()=>{if(old.time>5&&!old.done&&player.currentTime<1)player.currentTime=Math.min(old.time,Math.max(0,player.duration-1));},{once:true});
    player.addEventListener('timeupdate',()=>{if(Date.now()-last>5000){last=Date.now();saveVideo(v.id,player.currentTime);}});
    player.addEventListener('ended',()=>saveVideo(v.id,player.currentTime,true));
    dispose=()=>{if(player.currentTime>0)saveVideo(v.id,player.currentTime,player.ended);};
  }
  function filters() {
    const main=api.main, saved=read('videoFilters',{});
    const controls=document.createElement('div');controls.className='discovery panel';
    controls.innerHTML=`<label class="field">Video ara<input type="search" id="video-search" placeholder="Film, konu veya yapımcı" value="${esc(typeof saved.q==='string'?saved.q:'')}"></label><label class="field">Seviye<select id="video-level"><option value="all">Her seviye</option>${levels.map(l=>`<option value="${l}" ${saved.level===l?'selected':''}>${l}</option>`).join('')}</select></label><label class="field">Süre<select id="video-duration"><option value="all">Her uzunluk</option><option value="short">10 dakikadan kısa</option><option value="medium">10–30 dakika</option><option value="long">30 dakikadan uzun</option></select></label><label class="field">Altyazı<select id="video-subtitle"><option value="all">Tüm videolar</option><option value="ready">Dokunulabilir altyazı hazır</option><option value="custom">Kendi altyazını ekle</option></select></label><button class="btn sm" id="video-reset">Filtreleri temizle</button>`;
    main.querySelector('.video-cats').before(controls);
    const empty=document.createElement('p');empty.className='empty';empty.hidden=true;empty.textContent='Bu seçimle eşleşen video yok. Filtrelerini değiştirmeyi dene.';main.querySelector('#video-shelves').append(empty);
    const duration=controls.querySelector('#video-duration'),subtitle=controls.querySelector('#video-subtitle');
    if(['all','short','medium','long'].includes(saved.duration))duration.value=saved.duration;
    if(['all','ready','custom'].includes(saved.subtitle))subtitle.value=saved.subtitle;
    const apply=()=>{const q=controls.querySelector('#video-search').value.trim().toLocaleLowerCase('tr'),level=controls.querySelector('#video-level').value;let found=false;
      const cat=main.querySelector('[data-video-cat][aria-pressed="true"]')?.dataset.videoCat||'all';
      main.querySelectorAll('.video-shelf').forEach(shelf=>{let match=false;shelf.querySelectorAll('.video-card').forEach(card=>{const v=api.videos.find(v=>card.getAttribute('href')==='#v.'+v.id);if(!v)return;
        const ready=v.provider!=='youtube'||!!read('subtitles.'+v.id,null)?.cues?.length;
        const ok=(!q||(v.title+' '+v.summaryTr+' '+v.creator).toLocaleLowerCase('tr').includes(q))&&(level==='all'||v.level===level)&&(duration.value==='all'||(duration.value==='short'?v.durationSeconds<600:duration.value==='medium'?v.durationSeconds>=600&&v.durationSeconds<=1800:v.durationSeconds>1800))&&(subtitle.value==='all'||(subtitle.value==='ready'?ready:!ready));
        (card.closest('.dl-item')||card).hidden=!ok;match ||=ok;});
        const active=shelf.dataset.shelf==='downloads'?cat==='downloads':cat==='all'||cat===shelf.dataset.shelf;
        shelf.hidden=!active||(!match&&shelf.dataset.shelf!=='downloads');found ||=active&&match;
      });empty.hidden=found||cat==='downloads';write('videoFilters',{q,level,duration:duration.value,subtitle:subtitle.value});
    };
    controls.addEventListener('input',apply);controls.addEventListener('change',apply);
    main.querySelector('.video-cats').addEventListener('click',apply);main.querySelector('.dl-tab')?.addEventListener('click',apply);
    controls.querySelector('#video-reset').onclick=()=>{controls.querySelector('#video-search').value='';controls.querySelector('#video-level').value='all';duration.value='all';subtitle.value='all';main.querySelector('[data-video-cat="all"]').click();apply();};apply();
  }
  function cover(v) {
    const label=api.category(v).label;
    return `<div class="video-art cover cover-${esc(v.category)}" aria-hidden="true">${v.provider==='youtube'?`<img src="https://i.ytimg.com/vi/${esc(v.youtubeId)}/hqdefault.jpg" alt="" loading="lazy" decoding="async" width="480" height="360">`:''}<div class="cover-shade"></div><span class="cover-genre">${esc(label)}</span><strong>${esc(v.title)}</strong><span class="cover-play">${api.playIcon}</span></div>`;
  }
  function study() {
    const prefs=read('studyPrefs',{level:'B2',time:'15',mode:'video'}), main=api.main;
    main.innerHTML=`<div class="lib-head"><div><p class="eyebrow">Kendi ritminde İngilizce</p><h1>Bugünkü çalışmam</h1><p class="lead">Bir içerik seç, anlamını keşfet, kendi cümlelerinle kullan. Küçük ve düzenli çalışmalar için kişisel başlangıç noktan.</p></div><a class="btn" href="#backup">Yedekle ve taşı</a></div>
      <div class="panel study-settings"><label class="field">Çalışma seviyem<select id="study-level">${levels.map(l=>`<option ${prefs.level===l?'selected':''}>${l}</option>`).join('')}</select></label><label class="field">Ayırabileceğim süre<select id="study-time"><option value="10">10 dakika</option><option value="15">15 dakika</option><option value="30">30 dakika</option></select></label><label class="field">Bugün ne yapalım?<select id="study-mode"><option value="video">İzleyerek öğren</option><option value="story">Bir hikâye oku</option><option value="article">Bir makale keşfet</option></select></label></div><div id="study-plan"></div><div class="panel"><h2>Seviyeni bulmak için</h2><p>Önce kısa bir bölüm dene. Ana fikri takip edebiliyor ama yeni ifadelerle karşılaşıyorsan uygun bir yerde olabilirsin. Sürekli durmak zorunda kalıyorsan daha kolay bir içerik seç. Seviyeler rehberdir; sınav sonucu değildir.</p><a href="#about">Seviye yaklaşımımız →</a></div>`;
    document.getElementById('study-time').value=['10','15','30'].includes(prefs.time)?prefs.time:'15';document.getElementById('study-mode').value=['video','story','article'].includes(prefs.mode)?prefs.mode:'video';
    const draw=()=>{const level=document.getElementById('study-level').value,time=document.getElementById('study-time').value,mode=document.getElementById('study-mode').value;write('studyPrefs',{level,time,mode});const done=read('learning',{}),videos=read('videoProgress',{}),progress=read('progress',{});
      const pool=mode==='video'?api.videos:api.library.filter(t=>t.type===mode);
      const ranked=pool.slice();
      ranked.sort((a,b)=>{const score=t=>Math.abs(levels.indexOf(t.level)-levels.indexOf(level))*100+(done[t.id]?.done?300:0)+Math.abs((mode==='video'?t.durationSeconds/60:(t.words||0)/130)-Number(time)*0.6);return score(a)-score(b);});
      const selected=ranked.slice(0,3),resume=pool.filter(t=>mode==='video'?videos[t.id]?.time>5&&!videos[t.id]?.done:progress[t.id]?.f>0.03&&!progress[t.id]?.done).sort((a,b)=>(mode==='video'?videos[b.id].at-videos[a.id].at:progress[b.id].at-progress[a.id].at))[0];
      const link=t=>'#'+(mode==='video'?'v.':'s.')+t.id;
      document.getElementById('study-plan').innerHTML=`${resume?`<div class="resume-panel panel"><p class="eyebrow">Kaldığın yerden</p><h2>${esc(resume.title)}</h2><a class="btn primary" href="${link(resume)}">Devam et →</a></div>`:''}<div class="study-steps"><div><span>Hazırlan</span><p>Başlıktan tahmin yürüt. Bilmediğin kelimelere göz at.</p></div><div><span>Keşfet</span><p>Önce ana fikri yakala; sonra zorlandığın bölüme dön.</p></div><div><span>Kullan</span><p>İçeriğin sonundaki görevi yap, kelime kartlarını tekrar et.</p></div></div><div class="grid">${selected.map(t=>`<a class="card" href="${link(t)}"><span class="lvl lvl-${t.level}">${t.level}</span><h3>${esc(t.title)}</h3><p>${esc(t.summaryTr)}</p><span class="link">${done[t.id]?.done?'Yeniden çalış':'Çalışmaya başla'} →</span></a>`).join('')||'<p>Bu seçim için içerik bulunamadı.</p>'}</div><p class="sub">Öneriler çalışma seviyene, süre tercihine ve tamamladığın görevlere göre sıralanır. Daha uzun içerikleri bölümler hâlinde çalışabilirsin.</p><p><a class="btn" href="#words">Kelime kartlarına geç</a></p>`;
    };main.querySelector('.study-settings').onchange=draw;draw();
  }
  const allowedKeys=['words','progress','bookmarks','learning','videoProgress','studyPrefs'];
  function validateBackup(raw) {
    if(!raw||raw.app!=='Lantern English'||raw.version!==1||!raw.data||typeof raw.data!=='object')throw Error('Geçerli bir Lantern yedeği değil.');
    const result={}; const obj=v=>v&&typeof v==='object'&&!Array.isArray(v);const str=(v,max=4000)=>typeof v==='string'&&v.length<=max;
    for(const k of allowedKeys){const v=raw.data[k];if(v===undefined)continue;
      if(k==='bookmarks'){if(!Array.isArray(v)||v.some(x=>!str(x,200)))throw Error('Kitaplık kaydı geçersiz.');result[k]=v.filter(x=>api.library.some(t=>t.id===x));continue;}
      if(k==='studyPrefs'){if(!obj(v)||!levels.includes(v.level)||!['10','15','30'].includes(v.time)||!['video','story','article'].includes(v.mode))throw Error('Çalışma tercihleri geçersiz.');result[k]={level:v.level,time:v.time,mode:v.mode};continue;}
      if(!obj(v)||Object.keys(v).length>30000)throw Error('Yedek kaydı geçersiz.');const clean={};
      for(const [id,r]of Object.entries(v)){if(['__proto__','constructor','prototype'].includes(id)||!str(id,200)||!obj(r))throw Error('Yedekte geçersiz kayıt var.');
        if(k==='words'){if(!str(r.w,200)||!str(r.tr)||!Number.isFinite(r.added)||!Number.isFinite(r.due)||!Number.isInteger(r.box)||r.box<1||r.box>5)throw Error('Kelime kaydı geçersiz.');clean[id]={w:r.w,tr:r.tr,added:r.added,due:r.due,box:r.box};for(const p of ['form','pos','ctx','src'])if(str(r[p]))clean[id][p]=r[p];}
        if(k==='progress'){if(!api.library.some(t=>t.id===id))continue;if(!Number.isFinite(r.f)||r.f<0||r.f>1||!Number.isFinite(r.at))throw Error('Okuma kaydı geçersiz.');clean[id]={f:r.f,at:r.at,done:!!r.done};for(const p of ['page','pageF'])if(Number.isFinite(r[p])&&r[p]>=0&&r[p]<100000)clean[id][p]=r[p];}
        if(k==='learning'){if(!api.library.concat(api.videos).some(t=>t.id===id))continue;if(r.note!==undefined&&!str(r.note))throw Error('Çalışma notu geçersiz.');clean[id]={note:r.note||'',done:!!r.done,at:Number.isFinite(r.at)?r.at:0};}
        if(k==='videoProgress'){if(!api.videos.some(t=>t.id===id))continue;if(!Number.isFinite(r.time)||r.time<0||r.time>86400||!Number.isFinite(r.at))throw Error('İzleme kaydı geçersiz.');clean[id]={time:r.time,done:!!r.done,at:r.at};}
      }result[k]=clean;
    }return result;
  }
  function mergeBackup(data) {
    const originals={},next={};
    for(const [k,v]of Object.entries(data)){originals[k]=localStorage.getItem('lantern.'+k);const current=read(k,k==='bookmarks'?[]:{});
      if(k==='bookmarks')next[k]=Array.from(new Set([...current,...v]));
      else if(k==='studyPrefs')next[k]=v;
      else {next[k]={...current};for(const [id,rec]of Object.entries(v)){const a=current[id];if(!a||(rec.at||rec.added||0)>=(a.at||a.added||0))next[k][id]=rec;}}
    }
    try{for(const [k,v]of Object.entries(next))localStorage.setItem('lantern.'+k,JSON.stringify(v));}
    catch(error){for(const[k,v]of Object.entries(originals)){try{v===null?localStorage.removeItem('lantern.'+k):localStorage.setItem('lantern.'+k,v);}catch{}}throw Error('Yedek için yeterli depolama alanı yok. İçe aktarma tamamlanamadı.');}
  }
  function backup() {
    api.main.innerHTML=`<div class="lib-head"><div><p class="eyebrow">Çalışmaların seninle gelsin</p><h1>Yedekle ve taşı</h1><p class="lead">Kelime defterini, okuma ve izleme konumunu, kitaplığını ve çalışma notlarını başka bir tarayıcıya taşı.</p></div></div><div class="panel"><h2>Yedeğini indir</h2><p>JSON dosyasını sakla; diğer cihazında bu sayfayı açıp içe aktar. Bu işlem otomatik bulut eşitlemesi değildir. Video dosyaları ve kişisel altyazılar yedeğe dahil edilmez.</p><button class="btn primary" id="backup-export">Yedeği indir</button><h2>Yedeğimi içe aktar</h2><label class="field">Lantern yedeği<input type="file" id="backup-file" accept=".json,application/json"></label><p id="backup-status" role="status"></p><button class="btn" id="backup-apply" hidden>Mevcut çalışmalarımla birleştir</button><p class="sub">Kitaplıklar birleştirilir. Aynı içerikte daha yeni tarihli kayıt korunur. Çalışma tercihlerin yedekten alınır. Dosya bir sunucuya gönderilmez.</p></div>`;
    let pending=null;const status=document.getElementById('backup-status'),apply=document.getElementById('backup-apply');
    document.getElementById('backup-export').onclick=()=>{const data={};for(const k of allowedKeys){const v=read(k,null);if(v!==null)data[k]=v;}const url=URL.createObjectURL(new Blob([JSON.stringify({app:'Lantern English',version:1,createdAt:new Date().toISOString(),data},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='lantern-yedek-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);status.textContent='Yedek dosyası hazırlandı. İndirilenler klasörünü kontrol et.';};
    document.getElementById('backup-file').onchange=async e=>{pending=null;apply.hidden=true;const file=e.target.files[0];if(!file)return;try{if(file.size>15000000)throw Error('Yedek dosyası çok büyük.');pending=validateBackup(JSON.parse(await file.text()));status.textContent='Yedek doğrulandı. Onayladığında mevcut kayıtlarınla birleştirilecek.';apply.hidden=false;}catch(error){status.textContent=error.message;}};
    apply.onclick=()=>{if(!pending)return;try{mergeBackup(pending);pending=null;apply.hidden=true;api.reloadPersonal();status.textContent='Yedeğin birleştirildi. Çalışmalarına devam edebilirsin.';}catch(error){status.textContent=error.message;}};
  }
  function afterRoute(h) {
    if(h==='videos')filters();
    if(h==='home'){const block=document.createElement('section');block.className='panel study-invite';block.innerHTML='<div><p class="eyebrow">Bugün kendine bir keşif seç</p><h2>İngilizceyi izleyerek, okuyarak, kullanarak öğren.</h2><p>Seviyene ve ayırabildiğin süreye göre bir çalışma seç; kaldığın yerden devam et.</p></div><a class="btn primary" href="#study">Çalışma planımı aç →</a>';api.main.prepend(block);}
    if(h==='words'){const link=document.createElement('a');link.className='btn sm';link.href='#backup';link.textContent='Yedekle ve taşı';api.main.querySelector('.lib-head').append(link);}
    if(h==='about'){const box=document.createElement('section');box.innerHTML='<h2>Seviyeleri nasıl kullanıyoruz?</h2><p>Etiketler, içerik seçimine yardımcı olan Lantern tahminleridir; resmî CEFR onayı veya seviye sınavı sonucu değildir. Sözcük çeşitliliği yanında konuşma hızı, aksan, cümle yapısı, örtük anlam ve ihtiyaç duyulan ön bilgiyi birlikte ele alırız. Altyazıyla takip etmek ve altyazısız dinlemek farklı zorluklar taşır.</p><p>B2 düzeyinde ana savı ve ayrıntıları takip etmeye; C1 düzeyinde ima, doğal konuşma ve karmaşık açıklamalara; C2 çalışma önerilerinde hızlı diyalog, ince mizah ve üslup farklarına odaklan. Teknik kelime tek başına C2 göstergesi değildir. Öğretmen incelemesi tamamlanmış bir derecelendirme iddiasında bulunmuyoruz.</p><p><a href="https://www.coe.int/en/web/common-european-framework-reference-languages/level-descriptions" target="_blank" rel="noopener">CEFR seviye açıklamaları</a></p><h2>YouTube ile dokunarak öğrenme</h2><p>YouTube’un kendi CC yazıları yerine, eklediğin İngilizce SRT/VTT dosyası videonun altında eşzamanlı gösterilir. Buradaki kelimelere dokunarak anlamını görebilir ve defterine ekleyebilirsin. Tam ekran YouTube görünümünde bu alan görünmez; öğrenme için sayfa görünümünü kullan.</p><h2>Gizlilik ve devamlılık</h2><p>Çalışma notları ve kişisel altyazılar bu tarayıcıda tutulur. YouTube oynatıcısını başlatmak YouTube’a bağlanır; video kapakları YouTube görsel sunucusundan yüklenir. Cümle çevirisi kullandığında ilgili cümle MyMemory hizmetine gönderilir. Tarayıcı verilerini temizlemeden önce yedek al.</p><p><a class="btn" href="#backup">Yedekle ve başka cihaza taşı</a></p>';api.main.querySelector('.prose').append(box);}
    if(h.startsWith('s.')){const item=api.library.find(t=>t.id===h.slice(2));if(item)lesson(item,false);}
  }
  window.LanternLearning={init:context=>api=context,captions,parseSubtitles,youtube,cover,study,backup,afterRoute,lesson,nativeProgress,videoRecord,validateBackup,mergeBackup,cleanup:()=>{dispose();dispose=()=>{};}};
})();
